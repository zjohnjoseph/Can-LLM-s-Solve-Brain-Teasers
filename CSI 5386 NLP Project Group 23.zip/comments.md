Riddle: A pet store owner had a parrot with the sign "Parrot repeats everything it hears" on its cage. Davey bought the parrot and chatted to it for two weeks without it saying anything. He returned the parrot, but the shopkeeper said he had never lied about it. How is this possible?
Options:
A) Davey was deaf.
B) The parrot was deaf.
C) The parrot was tired.
D) None of above.
Choose the correct answer:
(Select one of the above options by typing A, B, C, or D)
Response: The correct answer is A) Davey was deaf.  The riddle states that the parrot repeats everything it hears, but it didn't say anything to Davey during the two weeks he chatted with it. This implies that Davey was unable
Answer: A
Correct: B
Wrong!

-------------------

Riddle: A pet shop owner had a parrot with a sign on its cage that said "Parrot repeats everything it hears". Davey bought the parrot and for two weeks he spoke to it and it didn't say a word. He returned the parrot but the shopkeeper said he never lied about the parrot. How can this be?
Options:
A) The parrot was tired.
B) Davey was deaf.
C) The parrot was deaf.
D) None of above.
Choose the correct answer:
(Select one of the above options by typing A, B, C, or D)
Response: A classic lateral thinking riddle!  After some thought, I think I have the answer:  C) The parrot was deaf.  The parrot "repeats everything it hears", but since it's deaf, it doesn't hear anything to repeat.
Answer: C
Correct: C
Right!